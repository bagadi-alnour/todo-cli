package uax29

//go:generate go run -C internal/gen main.go
